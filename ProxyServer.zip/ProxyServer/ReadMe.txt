Aysenur Ozgur 12c s19358


---Java HTTP Proxy Server---

A proxy server is a server that sits between the client and the remote server
 in which the client wishes to retrieve files from. All traffic that originates
 from the client, is sent to the proxy server and the proxy server makes requests
 to the remote server on the client�s behalf. Once the proxy server receives
 the required files, it then forwards them on to the client. This can be beneficial
 as it allows the proxy server administrator some control over what the machines on
 its network can do. 

In my project , TCP protocol used for communication.There are two main classes:
 Proxy class and Server class.The Server class is responsible for creating a ServerSocket 
which can accept incoming socket connections from the client.Implementation is multithreaded 
as the proxy must be able to serve multiple clients simultaneously.Thus once a socket
connection arrives, it is accepted and the server creates a new thread which services 
the request.
The Proxy class is responsible for servicing the requests that come through to 
proxy. The Proxy examines the request received and services the request
to the remoteserver.Then, takes the response from remote server and services the response to the client.

---The Implementation---
configuration;
1- you should change your proxy server settings with manual in your computer.
for windows --> Settings >> Network & Internet >> Proxy
IP: should be your own ip address
Port:55555
2- run the project (server class)
3- open your browser and type an url starts with http (not https), then check the project 
console and follow the requests and responses.

Don't forget about firewalls!

-Sometimes there are problems about getting response from server.(NullPointerException)
It works with http request but not with https.I thought that it could be about port numbers
(https port number:443).You will not get response from browser when you tried with https.




