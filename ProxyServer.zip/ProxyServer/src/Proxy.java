import java.io.*;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

public class Proxy extends Thread {
    private Socket client;

    Socket server;
    final byte[] request = new byte[1024];
    byte[] response = new byte[4096];
    PrintWriter out;
    BufferedReader in;

    public Proxy(Socket client) {
        super();
        this.client=client;
    }
    @Override
    public void run() {
        try {

              //URL url =new URL(sURL);
              //URLConnection conn =url.openConnection();

            InputStream FromClient = new BufferedInputStream(client.getInputStream()); //takes req from client
            OutputStream ToClient = client.getOutputStream(); // for incoming response
            int bytes_read=FromClient.read(request); //Reads some number of bytes from the input stream and stores them into the buffer array request.
            System.out.println(new String(request));
            String req = new String(request);
            if(req.contains("Host: ")) {
                String host = getHost(request);
                System.out.println("host : "+ host);


                try {
                    server = new Socket(host, 80); //http port:80

                    out = new PrintWriter(server.getOutputStream(), true);
                    in = new BufferedReader(new InputStreamReader(server.getInputStream()));

                } catch (IOException e) {
                    PrintWriter out = new PrintWriter(new OutputStreamWriter(ToClient));
                    out.println("Proxy server cannot connect");
                    out.flush();
                    client.close();
                }
                System.out.println("---------------------------------------------------------");
                InputStream fromServer = server.getInputStream(); //takes response from server
                OutputStream toServer = server.getOutputStream(); //for incoming requests


                try {
                        //Writes len bytes from the specified byte array starting at offset off to this output stream.
                        toServer.write(request, 0, bytes_read);//bytes_read =len
                        /*
                        String line;
                        while((line = in.readLine()) != null)
                        {
                            System.out.println(line);

                        }*/
                        toServer.flush();

                } catch (IOException e) {
                    System.out.println("error");
                }

                int bytes_read1;

                try {
                    while ((bytes_read1 = fromServer.read(response)) != -1) {
                        System.out.println(new String(response));
                        ToClient.write(response, 0, bytes_read1); //sending response to client
                        ToClient.flush();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                toServer.close();
                server.close();
                ToClient.close();
                client.close();

                System.out.println("------------------------------------------------");
            }
        } catch (IOException e) {

        }catch (NullPointerException e){
            System.out.println("no response");
        }

    }public String getHost(byte[] req) {
        String request = new String(req);
        String[] line = request.split("\r\n");
        String[] word = line[1].split(" ");
        return word[1];
    }


    }

