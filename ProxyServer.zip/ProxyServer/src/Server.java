import java.io.*;
import java.net.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Server {
    public static void main(String[] args) {
        ServerSocket server = null;
        Socket client = null;

       // Pattern p = Pattern.compile("((http|ftp|https):/\\/([\\w_-]+(?:(?:\\.[\\w_-]+)+))([\\w.,@?^=%&:/~+#-]*[\\w@?^=%&/~+#-])?)");
       // Matcher m = p.matcher(host);
            try {
                server = new ServerSocket(55555); //connection on port 55555

            } catch (IOException e) {
                System.out.println("Could not listen");
                System.exit(-1);
            }
            System.out.println("Server listens on port: " + server.getLocalPort());

            while (true) {
                try {
                    client = server.accept();
                    /*
                    BufferedReader bfr =new BufferedReader(new InputStreamReader(client.getInputStream()));
                    String line;
                    while((line = bfr.readLine()) != null && !line.isEmpty())
                    {
                        System.out.println(line);

                    }*/
                } catch (IOException e) {
                    System.out.println("Accept failed");
                    System.exit(-1);
                }

                (new Proxy(client)).start();
            }

        }



}